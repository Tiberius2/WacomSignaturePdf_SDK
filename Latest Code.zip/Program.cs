﻿using Softone;
using System;
using System.Threading;
using System.Windows.Forms;
using WacomSignaturePdf.Config;
using WacomSignaturePdf.Forms;

namespace WacomSignaturePdf
{
    [WorksOn("GENERAL")]
    public class S1 : TXCode
    {
        public static XSupport xSupp;

        public override void Initialize()
        {
            base.Initialize();
            xSupp = XSupport;
        }
    }
    [WorksOn("PRSNIN")]
    public class Program : TXCode
    {
        private static MainForm _activeForm;

        public override void Initialize()
        {
            base.Initialize();
        }

        public override object ExecCommand(int Cmd)
        {
            if (Cmd != 4000500)
                return null;

            try
            {
                // If the form is already open, just bring it to the front
                if (_activeForm != null && !_activeForm.IsDisposed)
                {
                    _activeForm.Invoke(new Action(() =>
                    {
                        if (_activeForm.WindowState == FormWindowState.Minimized)
                            _activeForm.WindowState = FormWindowState.Normal;
                        _activeForm.Activate();
                    }));
                    return base.ExecCommand(Cmd);
                }

                string officialName = string.Empty;
                string officialRole = string.Empty;
                try
                {
                    var userIdRaw = XSupport.ConnectionInfo.UserId;
                    if (int.TryParse(userIdRaw.ToString(), out int currentUserId))
                    {
                        var userResult = XSupport.GetSQLDataSet(
                            $"SELECT NAME FROM USERS WHERE USERS.USERS = {currentUserId}");
                        if (userResult != null && userResult.Count > 0)
                            officialName = userResult[0, "NAME"]?.ToString() ?? string.Empty;

                        officialRole = RoleHelper.GetRole(currentUserId);
                    }
                }
                catch { }

                var prsnTbl = XModule.GetTable("PRSN");
                if (prsnTbl == null || prsnTbl.Current == null)
                    return base.ExecCommand(Cmd);

                string personId = prsnTbl.Current["PRSN"]?.ToString() ?? string.Empty;
                string namePart = prsnTbl.Current["NAME"]?.ToString() ?? string.Empty;
                string name2Part = prsnTbl.Current["NAME2"]?.ToString() ?? string.Empty;
                string signerName = $"{namePart} {name2Part}".Trim();

                var thread = new Thread(() =>
                {
                    try
                    {
                        // Citim ultimul mod folosit (Template sau FreeForm)
                        var initialMode = ShellForm.LoadLastMode();

                        using (var shell = new ShellForm(
                            personId, signerName, officialName, officialRole, initialMode))
                        {
                            shell.ShowDialog();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"DocumentSigner error:\n{ex}", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        _activeForm = null;
                    }
                });

                thread.SetApartmentState(ApartmentState.STA);
                thread.IsBackground = true;
                thread.Start();
            }
            catch (Exception ex)
            {
                XSupport.Warning($"DocumentSigner ExecCommand error: {ex}");
            }

            return base.ExecCommand(Cmd);
        }
    }
}