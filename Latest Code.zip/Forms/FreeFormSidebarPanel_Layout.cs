﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using WacomSignaturePdf.Controls;
using WacomSignaturePdf.Theme;

namespace WacomSignaturePdf.Forms
{
    public partial class FreeFormSidebarPanel
    {
        #region Control Declarations

        private Label lblSectionDocument;
        private Button btnOpenFile;
        private Label lblLoadedFile;

        private Label lblSectionDraw;
        private Label lblDrawHint;
        private Button btnDrawZone;

        private Label lblSectionSignatures;
        private Label lblProgress;
        private Panel cardsPanel;

        private Button btnCancelLoad;
        private Button btnSaveAndClose;
        private Button btnFinish;

        private Panel panelBottom;
        private Label lblVersion;

        internal PdfDrawingOverlay pdfOverlay;   // wired to ShellForm.SharedOverlay

        private ToolTip toolTip;

        #endregion

        #region Layout Constants

        private const int BtnH = 38;
        private const int BtnSpacing = 10;
        private const int YDocSec = 12;
        private const int YOpenBtn = 32;
        private const int YFileLabel = 78;
        private const int YDrawSec = 108;
        private const int YDrawHint = 126;
        private const int YDrawBtn = 160;
        private const int YSigSec = 204;
        private const int YSigProg = 222;
        private const int YCards = 242;
        private const int CardsHeight = 290;

        private const int FieldX = 16;
        private const int ContentW = 428;   // SidebarWidth(460) - 16*2 padding simetric

        #endregion

        private void BuildSidebarControls()
        {
            var theme = AppTheme.FreeForm;

            // ── DOCUMENT ──
            lblSectionDocument = MakeSectionLabel("DOCUMENT", new Point(FieldX, YDocSec));

            btnOpenFile = new Button
            {
                Text = "📂  Deschide / Trage PDF",
                Location = new Point(FieldX, YOpenBtn),
                Size = new Size(ContentW, BtnH),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = AppTheme.FreeForm.AccentBar,
                ForeColor = Color.White,
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter,
            };
            btnOpenFile.FlatAppearance.BorderSize = 0;
            btnOpenFile.Click += (s, e) => BrowseForFile();

            lblLoadedFile = new Label
            {
                Text = "Niciun document incarcat.",
                Location = new Point(FieldX, YFileLabel),
                Size = new Size(ContentW, 22),
                Font = new Font("Segoe UI", 8.5f, FontStyle.Italic),
                ForeColor = theme.SidebarSub,
                BackColor = Color.Transparent,
                AutoEllipsis = true,
            };

            // ── ZONA SEMNATURA ──
            lblSectionDraw = MakeSectionLabel("ZONA SEMNATURA", new Point(FieldX, YDrawSec));

            lblDrawHint = new Label
            {
                Text = "Deseneaza un dreptunghi pe document pentru a plasa o semnatura.",
                Location = new Point(FieldX, YDrawHint),
                Size = new Size(ContentW, 32),
                Font = new Font("Segoe UI", 8.5f, FontStyle.Italic),
                ForeColor = theme.SidebarSub,
                BackColor = Color.Transparent,
            };

            btnDrawZone = new Button
            {
                Text = "✏  Adauga Semnatura Electronica",
                Location = new Point(FieldX, YDrawBtn),
                Size = new Size(ContentW, 34),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = AppTheme.FreeForm.AccentBar,
                ForeColor = Color.White,
                Enabled = false,
                Cursor = Cursors.Hand,
            };
            btnDrawZone.FlatAppearance.BorderSize = 0;
            btnDrawZone.Click += (s, e) =>
            {
                if (pdfOverlay.HasDocument) ShowDrawInstructions();
            };

            // ── SEMNATURI ──
            lblSectionSignatures = MakeSectionLabel("SEMNATURI", new Point(FieldX, YSigSec));

            lblProgress = new Label
            {
                Text = "",
                Location = new Point(FieldX, YSigProg),
                Size = new Size(ContentW, 18),
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = theme.SidebarSub,
                BackColor = Color.Transparent,
                AutoEllipsis = true,
            };

            cardsPanel = new Panel
            {
                Location = new Point(FieldX, YCards),
                Size = new Size(ContentW, CardsHeight),
                BackColor = AppTheme.FreeForm.SidebarCardsBg,
                AutoScroll = true,
                BorderStyle = BorderStyle.None,
            };

            // ── Action buttons ──
            btnCancelLoad = new Button
            {
                Text = "✕  Inchide document",
                Location = new Point(8, YCards + CardsHeight + 4),
                Size = new Size(ContentW, BtnH),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = AppTheme.CancelBg,
                ForeColor = Color.White,
                Visible = false,
                Cursor = Cursors.Hand,
            };
            btnCancelLoad.FlatAppearance.BorderSize = 0;
            btnCancelLoad.FlatAppearance.BorderColor = AppTheme.CancelBorder;
            btnCancelLoad.Click += (s, e) =>
            {
                if (!HasUnsavedWork) { UnloadDocument(); return; }
                using (var dlg = new ResetOrUnloadDialog(CanResetToOriginal))
                {
                    if (dlg.ShowDialog() != DialogResult.OK) return;
                    switch (dlg.SelectedAction)
                    {
                        case UnloadAction.DiscardSession: UnloadDocument(); break;
                        case UnloadAction.SaveAndClose: btnSaveAndClose_Click(null, EventArgs.Empty); break;
                        case UnloadAction.ResetToOriginal: ResetToOriginal(); break;
                    }
                }
            };

            btnSaveAndClose = new Button
            {
                Text = "💾  Salveaza si Inchide",
                Location = new Point(FieldX, 0),
                Size = new Size(ContentW, BtnH),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                BackColor = Color.FromArgb(30, 100, 160),
                ForeColor = Color.White,
                Cursor = Cursors.Hand,
                Enabled = false,
            };
            btnSaveAndClose.FlatAppearance.BorderSize = 0;
            btnSaveAndClose.FlatAppearance.BorderColor = AppTheme.AccentBorderBlue;
            btnSaveAndClose.Click += btnSaveAndClose_Click;

            btnFinish = new Button
            {
                Text = "Finalizati si Salvati",
                Location = new Point(8, YCards + CardsHeight + 4 + BtnH + BtnSpacing),
                Size = new Size(ContentW, BtnH),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = AppTheme.AccentGreen,
                ForeColor = Color.White,
                Enabled = false,
                Cursor = Cursors.Hand,
            };
            btnFinish.FlatAppearance.BorderSize = 0;
            btnFinish.FlatAppearance.BorderColor = AppTheme.AccentBorderGreen;
            btnFinish.Click += btnFinish_Click;

            WireButtonBorder(btnOpenFile);
            WireButtonBorder(btnCancelLoad);
            WireButtonBorder(btnSaveAndClose);
            WireButtonBorder(btnFinish);
            HandleDisabledTextColor(btnDrawZone);
            HandleDisabledTextColor(btnFinish);
            HandleDisabledTextColor(btnSaveAndClose);
            HandleDisabledTextColor(btnCancelLoad);

            toolTip = new ToolTip();
            toolTip.SetToolTip(btnOpenFile, "Selecteaza un PDF sau trage fisierul in zona de vizualizare");
            toolTip.SetToolTip(btnDrawZone, "Deseneaza o zona dreptunghiulara pe PDF pentru semnatura");
            toolTip.SetToolTip(btnSaveAndClose, "Salveaza configuratia sloturilor in document si inchide");
            toolTip.SetToolTip(btnFinish, "Exporta documentul semnat in Documente Semnate Liber si inchide");

            string ver = System.Reflection.Assembly.GetExecutingAssembly()
                             .GetName().Version?.ToString() ?? "—";
            lblVersion = new Label
            {
                Text = $"v{ver}",
                Dock = DockStyle.Bottom,
                Height = 16,
                Font = new Font("Segoe UI", 7f),
                ForeColor = Color.FromArgb(70, 130, 130),
                BackColor = theme.SidebarTitleBg,
                TextAlign = ContentAlignment.MiddleCenter,
            };

            this.Load += (s, e) => RecalcLayout();
            this.Resize += (s, e) => RecalcLayout();
        }

        private void RecalcLayout()
        {
            int bottomH = panelBottom?.Height ?? 48;
            int availH = this.ClientSize.Height - bottomH - 4;
            int btnsH = (BtnH * 3) + (BtnSpacing * 2);
            int y0 = availH - btnsH;
            btnCancelLoad.Location = new Point(FieldX, y0);
            btnSaveAndClose.Location = new Point(FieldX, y0 + BtnH + BtnSpacing);
            btnFinish.Location = new Point(FieldX, y0 + (BtnH + BtnSpacing) * 2);
            btnCancelLoad.Size = new Size(ContentW, BtnH);
            btnSaveAndClose.Size = new Size(ContentW, BtnH);
            btnFinish.Size = new Size(ContentW, BtnH);
            cardsPanel.Height = btnCancelLoad.Top - cardsPanel.Top - 8;
        }

        private void BuildSidebar()
        {
            // Wire shared overlay from ShellForm
            pdfOverlay = _shell.SharedOverlay;
            pdfOverlay.RectangleDrawn += OnRectangleDrawn;

            this.BackColor = AppTheme.FreeForm.SidebarBg;

            this.Controls.Add(lblSectionDocument);
            this.Controls.Add(btnOpenFile);
            this.Controls.Add(lblLoadedFile);
            this.Controls.Add(lblSectionDraw);
            this.Controls.Add(lblDrawHint);
            this.Controls.Add(btnDrawZone);
            this.Controls.Add(lblSectionSignatures);
            this.Controls.Add(lblProgress);
            this.Controls.Add(cardsPanel);
            this.Controls.Add(btnCancelLoad);
            this.Controls.Add(btnSaveAndClose);
            this.Controls.Add(btnFinish);

            panelBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 48,  // 32 status + 16 version
                BackColor = AppTheme.FreeForm.SidebarTitleBg,
            };
            lblVersion.Dock = DockStyle.Bottom;
            panelBottom.Controls.Add(lblVersion);
            this.Controls.Add(panelBottom);
        }

        #region Helpers

        private Label MakeSectionLabel(string text, Point location) =>
            new Label
            {
                Text = text,
                Location = location,
                Size = new Size(ContentW, 16),
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = AppTheme.FreeForm.SectionLabel,
                BackColor = Color.Transparent,
            };

        private static void WireButtonBorder(Button btn)
        {
            void UpdateStyle()
            {
                btn.FlatAppearance.BorderSize = btn.Enabled ? 2 : 0;
                btn.ForeColor = btn.Enabled ? Color.White : Color.FromArgb(110, 110, 110);
            }
            btn.EnabledChanged += (s, e) => UpdateStyle();
            UpdateStyle();
        }

        private static void HandleDisabledTextColor(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.UseVisualStyleBackColor = false;
            btn.Paint += (s, e) =>
            {
                if (!btn.Enabled)
                {
                    e.Graphics.Clear(btn.BackColor);
                    TextRenderer.DrawText(e.Graphics, btn.Text, btn.Font,
                        btn.ClientRectangle, Color.FromArgb(110, 110, 110),
                        TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                }
            };
        }

        #endregion
    }
}