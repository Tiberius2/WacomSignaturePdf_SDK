﻿using PdfiumViewer;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using WacomSignaturePdf.Controls;
using WacomSignaturePdf.Theme;

namespace WacomSignaturePdf.Forms
{
    /// <summary>
    /// Form unic care gazduieste ambele moduri (Template / FreeForm).
    /// Sidebar-ul e swap-uit la schimbarea modului.
    /// PdfViewer + previewHeader raman comune — nu se reincarca la switch.
    /// </summary>
    public partial class ShellForm : Form
    {
        // ── Mode ──────────────────────────────────────────────────────────────────
        public enum AppMode { Template, FreeForm }

        private AppMode _currentMode;

        // ── Shared viewer ─────────────────────────────────────────────────────────
        internal PdfViewer SharedPdfViewer { get; private set; }
        internal PdfDrawingOverlay SharedOverlay { get; private set; }

        // ── Current sidebar panel ─────────────────────────────────────────────────
        private ISidebarPanel _currentPanel;

        // ── Init params (passed to TemplateSidebarPanel) ──────────────────────────
        internal string InitPersonId { get; private set; }
        internal string InitSignerName { get; private set; }
        internal string InitOfficialName { get; private set; }
        internal string InitOfficialRole { get; private set; }

        // ── Singleton guard (same as original MainForm) ───────────────────────────
        private static ShellForm _instance;
        public static ShellForm Instance => _instance;

        // ── Constructor ───────────────────────────────────────────────────────────
        public ShellForm(string personId, string signerName,
                         string officialName, string officialRole,
                         AppMode initialMode)
        {
            _instance = this;
            InitPersonId = personId;
            InitSignerName = signerName;
            InitOfficialName = officialName;
            InitOfficialRole = officialRole;
            BuildLayout(initialMode);
            SwitchMode(initialMode, force: true);
        }

        // ── Mode persistence ──────────────────────────────────────────────────────
        private static string LastModeFile => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "WacomSignaturePdf", "last_mode.txt");

        public static AppMode LoadLastMode()
        {
            try
            {
                if (File.Exists(LastModeFile))
                    return File.ReadAllText(LastModeFile).Trim() == "FreeForm"
                        ? AppMode.FreeForm : AppMode.Template;
            }
            catch { }
            return AppMode.Template;
        }

        public static void SaveLastMode(AppMode mode)
        {
            try
            {
                var dir = Path.GetDirectoryName(LastModeFile);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(LastModeFile, mode.ToString());
            }
            catch { }
        }

        // ── Switch mode ───────────────────────────────────────────────────────────
        internal void SwitchMode(AppMode newMode, bool force = false)
        {
            if (!force && newMode == _currentMode) return;

            // 1. Verifica daca panelul curent are lucrari nesalvate
            if (!force && _currentPanel != null && _currentPanel.HasUnsavedWork)
            {
                using (var dlg = new ResetOrUnloadDialog(_currentPanel.CanResetToOriginal))
                {
                    var result = dlg.ShowDialog(this);
                    if (result == DialogResult.Cancel) return;
                    if (result == DialogResult.OK)
                    {
                        switch (dlg.SelectedAction)
                        {
                            case UnloadAction.SaveAndClose:
                                _currentPanel.SaveWork();
                                break;
                            case UnloadAction.ResetToOriginal:
                                _currentPanel.ResetToOriginal();
                                return; // ResetToOriginal nu face switch de mod
                            case UnloadAction.DiscardSession:
                            default:
                                break;
                        }
                    }
                }
            }

            // 2. Unload panelul curent
            if (_currentPanel != null)
            {
                _currentPanel.Unload();
                var oldCtrl = _currentPanel as Control;
                if (oldCtrl != null) panelSidebar.Controls.Remove(oldCtrl);
            }

            // 3. Creeaza noul panel
            ISidebarPanel newPanel;
            if (newMode == AppMode.Template)
                newPanel = new TemplateSidebarPanel(this);
            else
                newPanel = new FreeFormSidebarPanel(this);

            // 4. Monteaza in sidebar
            var newCtrl = (Control)newPanel;
            newCtrl.Dock = DockStyle.Fill;
            panelSidebar.Controls.Add(newCtrl);
            newCtrl.BringToFront();

            _currentPanel = newPanel;
            _currentMode = newMode;

            // 5. Aplica tema vizuala
            ApplyTheme(newMode);

            // 6. Salveaza preferinta
            SaveLastMode(newMode);

            // 7. Actualizeaza pill switcher
            UpdatePillSwitcher(newMode);
        }

        // ── Apply visual theme ────────────────────────────────────────────────────
        private void ApplyTheme(AppMode mode)
        {
            ApplyThemeColors(mode);
        }

        private void UpdatePillSwitcher(AppMode mode) { }

        // ── Helpers for sidebar panels ────────────────────────────────────────────
        internal void SetZoomEnabled(bool enabled)
        {
            if (btnZoomIn != null) btnZoomIn.Enabled = enabled;
            if (btnZoomOut != null) btnZoomOut.Enabled = enabled;
        }

        internal void SetPreviewCaption(string text)
        {
            if (lblPreviewCaption != null) lblPreviewCaption.Text = text;
        }

        // ── Mirror ────────────────────────────────────────────────────────────────
        private void BtnMirror_Click(object sender, EventArgs e)
        {
            if (_currentPanel is TemplateSidebarPanel tp)
            {
                tp.ToggleMirror();
                bool active = tp.MirrorActive;
                btnMirror.Text = active ? "✕  Inchide Oglindire" : "⊞  Oglindire";
                btnMirror.BackColor = active ? AppTheme.MirrorOff : AppTheme.MirrorOn;
            }
            else
            {
                MessageBox.Show(
                    "Oglindirea este disponibila doar in modul Sablon.",
                    "Oglindire", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void BtnPillTemplate_Click(object sender, EventArgs e)
            => SwitchMode(AppMode.Template);

        private void BtnPillFreeForm_Click(object sender, EventArgs e)
            => SwitchMode(AppMode.FreeForm);

        // ── Form close ────────────────────────────────────────────────────────────
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_currentPanel != null && _currentPanel.HasUnsavedWork)
            {
                using (var dlg = new ResetOrUnloadDialog(_currentPanel.CanResetToOriginal))
                {
                    var result = dlg.ShowDialog(this);
                    if (result == DialogResult.Cancel) { e.Cancel = true; return; }
                    if (result == DialogResult.OK)
                    {
                        switch (dlg.SelectedAction)
                        {
                            case UnloadAction.SaveAndClose: _currentPanel.SaveWork(); break;
                            case UnloadAction.ResetToOriginal: _currentPanel.ResetToOriginal(); break;
                        }
                    }
                }
            }
            _currentPanel?.Unload();
            base.OnFormClosing(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                SharedPdfViewer?.Dispose();
                SharedOverlay?.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // ── ISidebarPanel contract ────────────────────────────────────────────────────
    public interface ISidebarPanel
    {
        bool HasUnsavedWork { get; }
        bool CanResetToOriginal { get; }
        void ResetToOriginal();
        void SaveWork();
        void Unload();
        void OnFileDrop(string path);
    }
}