﻿using Newtonsoft.Json;
using PdfiumViewer;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.Advanced;
using PdfSharp.Pdf.IO;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using WacomSignaturePdf.Config;
using WacomSignaturePdf.Controls;
using WacomSignaturePdf.Models;
using WacomSignaturePdf.Services;
using WacomSignaturePdf.Theme;

namespace WacomSignaturePdf.Forms
{
    /// <summary>
    /// Free-form signing form: load any PDF, draw signature zones, configure and sign.
    /// Independent of template system. Persists slot configuration as JSON in PDF attachment.
    /// Output saved to: RecruitmentDocsPath/Documente Semnate Electronic - Semnatura Libera/
    /// </summary>
    public partial class FreeFormSidebarPanel : UserControl, ISidebarPanel
    {
        #region Fields

        private string _loadedPdfPath;      // path of the currently loaded PDF (working copy)
        private string _originalPdfPath;    // original file chosen by user (never modified)

        // Configured slots (from dialog + JSON attachment)
        private List<FreeFormSlot> _slots = new List<FreeFormSlot>();
        private List<SignatureCardPanel> _cards = new List<SignatureCardPanel>();

        // SignatureService for actual Wacom capture + PDF embedding
        private SignatureService _signatureService;

        private bool _captureInProgress;

        // Layout helper — set in BuildContentPanel, used in BuildForm

        // Output folder name inside WorkingRoot
        private const string OutputFolderName = "Documente Semnate Electronic - Semnatura Libera";
        private const string OriginalsFolder = "Documente Originale - Semnaturi Libere";

        // Flag: originalul a fost deja copiat in OriginalsFolder
        private bool _originalBackedUp;
        private string _originalDocHash; // SHA-256 al documentului original curat

        #endregion

        #region Constructor

        private readonly ShellForm _shell;

        public FreeFormSidebarPanel(ShellForm shell)
        {
            _shell = shell;
            DoubleBuffered = true;
            BuildSidebarControls();
            BuildSidebar();
        }

        // ── ISidebarPanel ─────────────────────────────────────────────────────────
        public bool HasUnsavedWork =>
            _loadedPdfPath != null && _cards != null && _cards.Any(c => c.Signed);

        public bool CanResetToOriginal => _originalPdfPath != null;

        public void SaveWork()
        {
            if (_loadedPdfPath == null) return;
            try
            {
                File.Copy(_loadedPdfPath, _originalPdfPath, overwrite: true);
            }
            catch { }
            UnloadDocument();
        }

        public void ResetToOriginal()
        {
            if (_originalPdfPath == null) return;

            // Daca nu s-a facut backup (nicio semnatura aplicata), simplu unload
            if (!_originalBackedUp)
            {
                UnloadDocument();
                return;
            }

            try
            {
                // Gasim copia originala in OriginalsFolder
                string root = AppConfig.WorkingRoot;
                if (string.IsNullOrEmpty(root)) return;

                string destDir = Path.Combine(root, OriginalsFolder);
                string baseName = Path.GetFileNameWithoutExtension(_originalPdfPath);

                // Cel mai recent fisier cu acelasi nume de baza din folder
                if (!Directory.Exists(destDir)) return;
                var candidates = Directory.GetFiles(destDir, $"{baseName}_*.pdf")
                    .OrderByDescending(f => f).ToArray();
                if (candidates.Length == 0)
                {
                    MessageBox.Show("Nu s-a gasit originalul in folderul de backup.",
                        "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string originalBackup = candidates[0];

                // Inlocuieste documentul curent cu originalul
                File.Copy(originalBackup, _originalPdfPath, overwrite: true);

                // Sterge backup-ul din OriginalsFolder
                try { File.Delete(originalBackup); } catch { }

                UnloadDocument();

                MessageBox.Show(
                    $"Documentul a fost resetat la versiunea originala.",
                    "Resetat", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la resetare:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Unload()
        {
            UnloadDocument();
        }

        public void OnFileDrop(string path) => LoadPdf(path);

        #endregion

        #region File Loading



        // ── Default mode (persistent in AppData) ─────────────────────────────────
        // ── Draw instructions dialog ──────────────────────────────────────────────

        private static string DrawHintSkipFile =>
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WacomSignaturePdf", "skip_draw_hint.txt");

        private void ShowDrawInstructions()
        {
            bool skip = File.Exists(DrawHintSkipFile);

            if (!skip)
            {
                using (var dlg = new DrawInstructionsDialog())
                {
                    dlg.ShowDialog(_shell);
                    if (dlg.DontShowAgain)
                    {
                        try
                        {
                            var dir = Path.GetDirectoryName(DrawHintSkipFile);
                            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                            File.WriteAllText(DrawHintSkipFile, "1");
                        }
                        catch { }
                    }
                }
            }

            pdfOverlay.EnableDrawing(true);
        }

        private void BrowseForFile()
        {
            using (var dlg = new OpenFileDialog
            {
                Title = "Selecteaza un document PDF",
                Filter = "PDF Files (*.pdf)|*.pdf",
                CheckFileExists = true
            })
            {
                if (dlg.ShowDialog(_shell) == DialogResult.OK)
                    LoadPdf(dlg.FileName);
            }
        }

        private void LoadPdf(string path)
        {
            try
            {
                // Verifica daca documentul e finalizat
                var existingState = SignatureService.ReadSigningState(path);
                if (existingState?.Finalized == true)
                {
                    MessageBox.Show(
                        "Acest document a fost deja finalizat si exportat.\n\n" +
                        "Documentele finalizate nu pot fi redeschise pentru semnare.",
                        "Document Finalizat",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                // Verifica daca documentul e de tip Template — blocat in FreeForm
                if (existingState?.Source == "Template")
                {
                    MessageBox.Show(
                        "Acest document a fost creat prin fluxul Sablon si nu poate fi deschis in modul Semnatura Libera.\n\n" +
                        "Comutati pe modul Sablon pentru a continua semnarea acestui document.",
                        "Document Sablon",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                // If a document is already loaded, unload it first
                if (_loadedPdfPath != null) UnloadDocument();

                // Work on a temp copy so original stays untouched until Save
                string tempPath = Path.Combine(
                    Path.GetTempPath(),
                    $"freeform_{DateTime.Now:yyyyMMdd_HHmmss_fff}_{Path.GetFileName(path)}");
                File.Copy(path, tempPath, overwrite: true);

                _originalPdfPath = path;
                _loadedPdfPath = tempPath;
                _originalBackedUp = false;
                _originalDocHash = null;

                // Load in overlay viewer
                pdfOverlay.LoadDocument(tempPath);
                _shell.SetZoomEnabled(true);
                btnDrawZone.Enabled = true;

                // Update sidebar
                lblLoadedFile.Text = Path.GetFileName(path);
                lblLoadedFile.ForeColor = Color.FromArgb(180, 230, 180);
                _shell.SetPreviewCaption(Path.GetFileName(path));
                btnCancelLoad.Visible = true;
                btnSaveAndClose.Enabled = true;

                // Initialize SignatureService with an empty slot list (will be populated from config)
                _slots.Clear();
                _cards.Clear();
                cardsPanel.Controls.Clear();
                UpdateProgress();

                // Read existing slot config from the ORIGINAL file (not temp copy)
                // so we pick up any previously saved configuration
                var existing = ReadSlotConfig(path);
                if (existing != null && existing.Count > 0)
                {
                    _slots = existing;
                    RebuildAllCards();
                    lblDrawHint.Text = $"{existing.Count} semnatura(ri) incarcate din document.";
                }
                else
                {
                    lblDrawHint.Text = "Deseneaza un dreptunghi pe document pentru a plasa o semnatura.";
                }

                // Restore signed state din JSON attachment (fara SignatureService)
                RestoreSignedState();
                RefreshPreviewSlots();

                lblProgress.Text = $"Document incarcat. {_slots.Count} sloturi configurate.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la incarcarea documentului:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UnloadDocument()
        {
            _signatureService?.Dispose();
            _signatureService = null;

            pdfOverlay.UnloadDocument();
            pdfOverlay.ClearPreviewSlots();
            _shell.SetZoomEnabled(false);
            btnDrawZone.Enabled = false;

            // Clean up temp copy
            if (_loadedPdfPath != null && File.Exists(_loadedPdfPath))
                try { File.Delete(_loadedPdfPath); } catch { }

            _loadedPdfPath = null;
            _originalPdfPath = null;

            _slots.Clear();
            _cards.Clear();
            cardsPanel.Controls.Clear();
            UpdateProgress();

            lblLoadedFile.Text = "Niciun document incarcat.";
            lblLoadedFile.ForeColor = AppTheme.SidebarSub;
            _shell.SetPreviewCaption("Previzualizare — trage un PDF sau apasa Deschide");
            lblDrawHint.Text = "Deseneaza un dreptunghi pe document pentru a plasa o semnatura.";
            lblProgress.Text = "";
            btnCancelLoad.Visible = false;
            btnSaveAndClose.Enabled = false;
            btnFinish.Enabled = false;
            pdfOverlay.EnableDrawing(false);
        }

        #endregion

        #region Original Backup

        /// <summary>
        /// Copiaza documentul original (curat, fara atasamente) in OriginalsFolder,
        /// prima data cand userul face o modificare (adaugare slot sau semnare).
        /// </summary>
        private void BackupOriginalOnce()
        {
            if (_originalBackedUp || _originalPdfPath == null) return;
            try
            {
                // Daca documentul are deja signing-state, originalul a fost deja salvat anterior
                var existingState = SignatureService.ReadSigningState(_originalPdfPath);
                if (existingState?.Source == "FreeForm")
                {
                    // Refolosim hash-ul existent
                    _originalDocHash = existingState.OriginalDocumentHash;
                    _originalBackedUp = true;
                    return;
                }

                string root = AppConfig.WorkingRoot;
                if (string.IsNullOrEmpty(root)) return;

                string destDir = Path.Combine(root, OriginalsFolder);
                Directory.CreateDirectory(destDir);

                // Nume unic: originalName_yyyyMMdd_HHmmss.pdf
                string baseName = Path.GetFileNameWithoutExtension(_originalPdfPath);
                string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string destPath = Path.Combine(destDir, $"{baseName}_{stamp}.pdf");

                // Copiem originalul curat (prima data, inainte de orice atasament)
                File.Copy(_originalPdfPath, destPath, overwrite: false);
                _originalBackedUp = true;

                // Calculeaza SHA-256 din originalul curat
                using (var sha = System.Security.Cryptography.SHA256.Create())
                using (var fs = File.OpenRead(_originalPdfPath))
                {
                    var hashBytes = sha.ComputeHash(fs);
                    _originalDocHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                }
            }
            catch { /* non-fatal */ }
        }

        #endregion

        #region Rectangle Drawn → Slot Config Dialog

        private void OnRectangleDrawn(DrawnRectangle rect)
        {
            if (_loadedPdfPath == null) return;

            int nextId = _slots.Count == 0 ? 1 : _slots.Max(s => s.SignatureId) + 1;

            using (var dlg = new FreeFormSlotDialog(nextId, rect.X, rect.Y, rect.W, rect.H, rect.Page))
            {
                if (dlg.ShowDialog(_shell) != DialogResult.OK) return;

                // Guard: SignatureId must be unique
                if (_slots.Any(s => s.SignatureId == dlg.SignatureId))
                {
                    MessageBox.Show(
                        $"Exista deja o semnatura cu ID #{dlg.SignatureId}. Alegeti un ID diferit.",
                        "ID duplicat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var slot = new FreeFormSlot
                {
                    SignatureId = dlg.SignatureId,
                    SignerName = dlg.SignerName,
                    Reason = dlg.Reason,
                    Party = dlg.Party,
                    OfficialRole = dlg.OfficialRole,
                    Required = dlg.Required,
                    Biometric = dlg.Biometric,
                    Page = rect.Page,
                    X = rect.X,
                    Y = rect.Y,
                    W = rect.W,
                    H = rect.H
                };

                _slots.Add(slot);

                // Persist slot config into working copy
                BackupOriginalOnce();
                SaveSlotConfigToPdf(_loadedPdfPath);

                // Reincarca viewer
                pdfOverlay.LoadDocumentRestoring(_loadedPdfPath);
                RefreshPreviewSlots();

                // Add card (unsigned)
                AddCard(slot, signed: false, actualSignerName: null);
                UpdateProgress();

                if (dlg.SignImmediately)
                    CaptureForSlot(slot);
            }
        }

        #endregion

        #region Signature Cards

        private void RebuildAllCards()
        {
            cardsPanel.Controls.Clear();
            _cards.Clear();
            foreach (var slot in _slots)
                AddCard(slot, signed: false, actualSignerName: null);
            UpdateProgress();
        }

        private void AddCard(FreeFormSlot slot, bool signed, string actualSignerName)
        {
            // Build a SignatureSlot proxy so we can reuse SignatureCardPanel
            var sigSlot = SlotToSignatureSlot(slot);

            var card = new SignatureCardPanel(sigSlot);
            card.Width = cardsPanel.Width - 12;

            if (signed && actualSignerName != null)
                card.MarkSigned(actualSignerName);

            card.CardClicked += s => OnCardClicked(slot);
            cardsPanel.Controls.Add(card);
            _cards.Add(card);

            // Reflow
            int y = 6;
            foreach (SignatureCardPanel c in cardsPanel.Controls)
            {
                c.Location = new Point(6, y);
                y += c.Height + 6;
            }
        }

        private void OnCardClicked(FreeFormSlot slot)
        {
            if (_captureInProgress) return;
            var card = FindCard(slot.SignatureId);
            if (card == null || card.Signed) return;

            CaptureForSlot(slot);
        }

        private SignatureCardPanel FindCard(int signatureId)
        {
            for (int i = 0; i < _cards.Count; i++)
                if (_cards[i].Slot.SignatureId == signatureId)
                    return _cards[i];
            return null;
        }

        #endregion

        #region Signature Capture

        private void CaptureForSlot(FreeFormSlot slot)
        {
            if (_loadedPdfPath == null) return;
            if (_captureInProgress) return;

            try
            {
                _signatureService?.Dispose();
                _signatureService = null;
                var sigSlots = _slots.Select(SlotToSignatureSlot).ToList();
                _signatureService = new SignatureService(
                    _loadedPdfPath, artifactsRootDir: "", allSlots: sigSlots);
            }
            catch (IOException ex)
            {
                // Reload viewer inainte de a arata eroarea
                pdfOverlay.LoadDocumentRestoring(_loadedPdfPath);
                MessageBox.Show(ex.Message, "Fisier blocat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            BackupOriginalOnce();
            SetCardsEnabled(false);
            _captureInProgress = true;

            var thread = new Thread(() =>
            {
                Exception caughtEx = null;
                bool cancelled = false;
                string actualSigner = slot.SignerName;

                try
                {
                    _signatureService.CaptureAndEmbed(
                        slot.SignatureId, slot.Party,
                        slot.SignerName, slot.Reason,
                        slot.Page,
                        slot.X, slot.Y, slot.W, slot.H,
                        isImputernicire: false);
                }
                catch (OperationCanceledException) { cancelled = true; }
                catch (Exception ex) { caughtEx = ex; }

                Invoke(new Action(() =>
                {
                    _captureInProgress = false;
                    SetCardsEnabled(true);

                    if (cancelled)
                    {
                        // Wacom cancel — reload viewer (fusese descarcat pentru scriere)
                        pdfOverlay.LoadDocumentRestoring(_loadedPdfPath);
                        return;
                    }

                    if (caughtEx != null)
                    {
                        pdfOverlay.LoadDocumentRestoring(_loadedPdfPath);
                        if (IsWacomMissingError(caughtEx))
                        {
                            MessageBox.Show(
                                "Dispozitivul de semnatura nu este conectat sau nu este disponibil.\n\n" +
                                "Conectati tableta Wacom si reincercati.",
                                "Dispozitiv Neconectat",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            MessageBox.Show(caughtEx.Message, "Eroare Captura",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        return;
                    }

                    // Success
                    var card = FindCard(slot.SignatureId);
                    card?.MarkSigned(slot.SignerName);
                    UpdateProgress();
                    CheckFinishEnabled();
                    RefreshPreviewSlots();

                    // 1. Citim signing state INAINTE ca SaveIntermediateNoState sa-l stearga
                    var stateBeforeWrite = SignatureService.ReadSigningState(_loadedPdfPath);
                    // 2. Scrie semnatura biometrica in PDF (sterge signing state intern)
                    _signatureService.SaveIntermediateNoState();
                    // 3. Rescrie signing state FreeForm corect (cu semnatura noua + cele anterioare)
                    AttachSigningStateToFile(slot, stateBeforeWrite);
                    pdfOverlay.LoadDocumentRestoring(_loadedPdfPath);
                }));
            });

            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private static bool IsWacomMissingError(Exception ex)
        {
            string msg = ex.Message + ex.GetType().Name;
            return msg.Contains("STU") || msg.Contains("pad") || msg.Contains("Pad")
                || msg.Contains("device") || msg.Contains("DynCaptPadError")
                || msg.Contains("DynCaptNotLicensed")
                || msg.Contains("COMException") || msg.Contains("Florentis");
        }



        private void LoadDocumentWithRestore(string path)
        {
            try { pdfOverlay.LoadDocumentRestoring(path); }
            catch { pdfOverlay.LoadDocument(path); }
        }

        private void AttachSigningStateAfterWrite(FreeFormSlot slot)
        {
            try
            {
                byte[] pdfBytes = File.ReadAllBytes(_loadedPdfPath);
                string tempOut = _loadedPdfPath + ".tmp";
                using (var ms = new MemoryStream(pdfBytes))
                using (var doc = PdfSharp.Pdf.IO.PdfReader.Open(ms, PdfSharp.Pdf.IO.PdfDocumentOpenMode.Modify))
                {
                    RemoveStateAttachment(doc);
                    AttachSigningStateDirect(doc, slot);
                    doc.Save(tempOut);
                }
                File.Delete(_loadedPdfPath);
                File.Move(tempOut, _loadedPdfPath);
            }
            catch { }
        }

        #endregion

        #region Signing State (freeform-specific — parallel to SignatureService.AttachSigningState)

        /// <summary>
        /// Reads signing-state.json from the PDF to restore which slots were already signed.
        /// </summary>
        private void RestoreSignedState()
        {
            if (_loadedPdfPath == null) return;

            var state = SignatureService.ReadSigningState(_loadedPdfPath);
            if (state?.Slots == null) return;

            foreach (var entry in state.Slots.Where(s => s.Signed))
            {
                var card = FindCard(entry.SignatureId);
                card?.MarkSigned(entry.ActualSignerName ?? entry.SignerName);
            }

            UpdateProgress();
            CheckFinishEnabled();
        }

        /// <summary>
        /// Used by placeholder path: directly updates signing-state in the open PdfDocument.
        /// Merges with existing state so prior-session signatures are not lost.
        /// </summary>
        /// <summary>
        /// Scrie signing state in _loadedPdfPath dupa o semnatura reusita.
        /// Inlocuieste SaveIntermediate (care nu stia de Source=FreeForm).
        /// </summary>
        private void AttachSigningStateToFile(FreeFormSlot justSigned, SigningState previousState = null)
        {
            try
            {
                string tempOut = _loadedPdfPath + ".tmp";
                byte[] pdfBytes = File.ReadAllBytes(_loadedPdfPath);
                using (var ms = new MemoryStream(pdfBytes))
                using (var doc = PdfSharp.Pdf.IO.PdfReader.Open(ms, PdfSharp.Pdf.IO.PdfDocumentOpenMode.Modify))
                {
                    WriteSigningStateToPdfDoc(doc, justSigned, previousState);
                    doc.Save(tempOut);
                }
                File.Delete(_loadedPdfPath);
                File.Move(tempOut, _loadedPdfPath);
            }
            catch { /* non-fatal */ }
        }

        /// <summary>
        /// Construieste SigningState complet si il scrie in documentul PdfSharp deschis.
        /// justSignedSlot = null inseamna doar salvare configuratie (fara a marca ca semnat).
        /// </summary>
        private void WriteSigningStateToPdfDoc(PdfSharp.Pdf.PdfDocument document, FreeFormSlot justSignedSlot, SigningState existingState = null, bool finalized = false)
        {
            // Daca nu e furnizat explicit, citim din PDF (pentru cazul SaveSlotConfig fara semnare)
            if (existingState == null)
                existingState = SignatureService.ReadSigningState(_loadedPdfPath);
            var previousSigned = existingState?.Slots?
                .Where(e => e.Signed && (justSignedSlot == null || e.SignatureId != justSignedSlot.SignatureId))
                .ToDictionary(e => e.SignatureId)
                ?? new Dictionary<int, SigningStateEntry>();

            var stateObj = new SigningState
            {
                OriginalDocumentHash = _originalDocHash
                    ?? existingState?.OriginalDocumentHash
                    ?? string.Empty,
                Source = "FreeForm",
                Finalized = finalized || (existingState?.Finalized ?? false),
                Slots = _slots.Select(s =>
                {
                    var geo = new FreeFormSlotGeometry
                    {
                        Page = s.Page,
                        X = s.X,
                        Y = s.Y,
                        W = s.W,
                        H = s.H,
                        OfficialRole = s.OfficialRole,
                        Required = s.Required,
                        Biometric = s.Biometric,
                    };

                    if (justSignedSlot != null && s.SignatureId == justSignedSlot.SignatureId)
                        return new SigningStateEntry
                        {
                            SignatureId = s.SignatureId,
                            Party = s.Party,
                            SignerName = s.SignerName,
                            ActualSignerName = s.SignerName,
                            Reason = s.Reason,
                            Signed = true,
                            SignedAt = DateTime.Now,
                            MachineName = Environment.MachineName,
                            FreeForm = geo,
                        };

                    if (previousSigned.TryGetValue(s.SignatureId, out var prev))
                        return new SigningStateEntry
                        {
                            SignatureId = prev.SignatureId,
                            Party = prev.Party,
                            SignerName = prev.SignerName,
                            ActualSignerName = prev.ActualSignerName ?? prev.SignerName,
                            Reason = prev.Reason,
                            Signed = true,
                            SignedAt = prev.SignedAt,
                            MachineName = prev.MachineName,
                            FreeForm = prev.FreeForm ?? geo,
                        };

                    return new SigningStateEntry
                    {
                        SignatureId = s.SignatureId,
                        Party = s.Party,
                        SignerName = s.SignerName,
                        Reason = s.Reason,
                        Signed = false,
                        FreeForm = geo,
                    };
                }).ToList()
            };

            RemoveStateAttachment(document);
            PdfAttachmentHelper.AttachFile(document, "signing-state.json",
                "Document Signing State",
                Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(stateObj, Formatting.Indented)));
        }

        private void AttachSigningStateDirect(PdfSharp.Pdf.PdfDocument document, FreeFormSlot justSigned)
            => WriteSigningStateToPdfDoc(document, justSigned);

        private static void RemoveStateAttachment(PdfSharp.Pdf.PdfDocument document)
        {
            var nameArray = PdfAttachmentHelper.GetEmbeddedFilesArray(document);
            if (nameArray == null) return;

            for (int i = 0; i + 1 < nameArray.Elements.Count; i += 2)
            {
                var key = nameArray.Elements[i] as PdfString;
                if (key?.Value == "signing-state.json")
                {
                    nameArray.Elements.RemoveAt(i + 1);
                    nameArray.Elements.RemoveAt(i);
                    return;
                }
            }
        }

        #endregion

        private void MarkAsFinalized()
        {
            try
            {
                string tempOut = _loadedPdfPath + ".tmp";
                byte[] pdfBytes = File.ReadAllBytes(_loadedPdfPath);
                using (var ms = new System.IO.MemoryStream(pdfBytes))
                using (var doc = PdfSharp.Pdf.IO.PdfReader.Open(ms, PdfSharp.Pdf.IO.PdfDocumentOpenMode.Modify))
                {
                    WriteSigningStateToPdfDoc(doc, justSignedSlot: null, finalized: true);
                    doc.Save(tempOut);
                }
                File.Delete(_loadedPdfPath);
                File.Move(tempOut, _loadedPdfPath);
            }
            catch { }
        }

        #region Slot Config (prin signing-state.json)

        /// <summary>
        /// Salveaza configuratia sloturilor in signing-state.json (fara a marca ca semnate).
        /// Inlocuieste freeform-slots.json — un singur attachment per document.
        /// </summary>
        private void SaveSlotConfigToPdf(string pdfPath)
        {
            try
            {
                string tempOut = pdfPath + ".tmp";
                byte[] pdfBytes = File.ReadAllBytes(pdfPath);
                using (var ms = new MemoryStream(pdfBytes))
                using (var doc = PdfSharp.Pdf.IO.PdfReader.Open(ms, PdfSharp.Pdf.IO.PdfDocumentOpenMode.Modify))
                {
                    WriteSigningStateToPdfDoc(doc, justSignedSlot: null);
                    doc.Save(tempOut);
                }
                File.Delete(pdfPath);
                File.Move(tempOut, pdfPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la salvarea configuratiei:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// Citeste sloturile din signing-state.json (campul FreeForm per entry).
        /// Inlocuieste ReadSlotConfig (freeform-slots.json).
        /// </summary>
        private static List<FreeFormSlot> ReadSlotConfig(string pdfPath)
        {
            try
            {
                var state = SignatureService.ReadSigningState(pdfPath);
                if (state?.Source != "FreeForm" || state.Slots == null) return null;
                return state.Slots
                    .Where(e => e.FreeForm != null)
                    .Select(e => new FreeFormSlot
                    {
                        SignatureId = e.SignatureId,
                        SignerName = e.SignerName,
                        Reason = e.Reason,
                        Party = e.Party,
                        OfficialRole = e.FreeForm.OfficialRole,
                        Required = e.FreeForm.Required,
                        Biometric = e.FreeForm.Biometric,
                        Page = e.FreeForm.Page,
                        X = e.FreeForm.X,
                        Y = e.FreeForm.Y,
                        W = e.FreeForm.W,
                        H = e.FreeForm.H,
                    }).ToList();
            }
            catch { }
            return null;
        }

        #endregion

        #region SignatureService Management

        private void RebuildSignatureService()
        {
            _signatureService?.Dispose();
            _signatureService = null;

            if (_loadedPdfPath == null) return;

            // Convert FreeFormSlots to SignatureSlots for SignatureService
            var sigSlots = _slots.Select(SlotToSignatureSlot).ToList();

            _signatureService = new SignatureService(
                _loadedPdfPath,
                artifactsRootDir: "",
                allSlots: sigSlots);
        }

        private static SignatureSlot SlotToSignatureSlot(FreeFormSlot s) =>
            new SignatureSlot
            {
                SignatureId = s.SignatureId,
                SignerName = s.SignerName,
                ResolvedSignerName = s.SignerName,
                Reason = s.Reason,
                Page = s.Page.ToString(),
                ResolvedPage = s.Page,
                Party = s.Party,
                OfficialRole = s.OfficialRole,
                Required = s.Required,
                Biometric = s.Biometric,
                Location = new SignatureLocation
                {
                    X = s.X,
                    Y = s.Y,
                    W = s.W,
                    H = s.H
                }
            };

        #endregion

        #region Finalize

        private void btnSaveAndClose_Click(object sender, EventArgs e)
        {
            if (_loadedPdfPath == null) return;
            try
            {
                // Copiaza working copy (cu semnaturi + signing state) peste originalul ales de user
                File.Copy(_loadedPdfPath, _originalPdfPath, overwrite: true);

                MessageBox.Show(
                    $"Document salvat:\n{Path.GetFileName(_originalPdfPath)}",
                    "Salvat", MessageBoxButtons.OK, MessageBoxIcon.Information);

                UnloadDocument();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la salvare:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            if (_loadedPdfPath == null) return;

            // Blocat daca nu toate semnaturile sunt semnate
            int unsigned = _cards.Count(c => !c.Signed);
            if (unsigned > 0)
            {
                MessageBox.Show(
                    $"Exista {unsigned} semnatura(ri) nesemnate.\n\n" +
                    "Toate semnaturile trebuie completate inainte de finalizare.",
                    "Semnaturi incomplete", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string root = AppConfig.WorkingRoot ?? Path.GetDirectoryName(_originalPdfPath);
                string outputDir = Path.Combine(root, OutputFolderName);
                Directory.CreateDirectory(outputDir);

                // Nume final: originalName_Semnat.pdf
                string baseName = Path.GetFileNameWithoutExtension(_originalPdfPath);
                string dest = Path.Combine(outputDir, $"{baseName}_Semnat.pdf");

                // Marcheaza documentul ca finalizat in signing state
                MarkAsFinalized();

                // Copiaza working copy (cu semnaturi embeddate) in output folder
                File.Copy(_loadedPdfPath, dest, overwrite: true);

                // Deschide in Adobe
                System.Diagnostics.Process.Start(
                    new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = dest,
                        UseShellExecute = true
                    });

                MessageBox.Show(
                    $"Document finalizat:\n{dest}",
                    "Finalizat", MessageBoxButtons.OK, MessageBoxIcon.Information);

                UnloadDocument();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Eroare la finalizare:\n{ex.Message}",
                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Helpers

        private void RefreshPreviewSlots()
        {
            if (_slots == null || _slots.Count == 0)
            {
                pdfOverlay.ClearPreviewSlots();
                return;
            }

            var rects = new DrawnRectangle[_slots.Count];
            var signed = new bool[_slots.Count];
            for (int i = 0; i < _slots.Count; i++)
            {
                var s = _slots[i];
                rects[i] = new DrawnRectangle
                {
                    Page = s.Page,
                    X = s.X,
                    Y = s.Y,
                    W = s.W,
                    H = s.H,
                    RoleLabel = !string.IsNullOrEmpty(s.OfficialRole) ? s.OfficialRole
              : s.Party == "Candidate" ? "Candidat / Angajat"
              : s.Party
                };
                var card = FindCard(s.SignatureId);
                signed[i] = card?.Signed ?? false;
            }
            pdfOverlay.SetPreviewSlots(rects, signed);
        }

        private void SetCardsEnabled(bool enabled)
        {
            foreach (var c in _cards)
                if (!c.Signed && !c.RoleRestricted)
                    c.Enabled = enabled;
        }

        private void UpdateProgress()
        {
            int signed = _cards.Count(c => c.Signed);
            int total = _cards.Count;
            lblProgress.Text = total == 0
                ? "Nicio semnatura configurata."
                : $"{signed} din {total} semnaturi completate";
        }

        private void CheckFinishEnabled()
        {
            // Finalizare disponibila doar cand TOATE semnaturile sunt semnate
            bool allSigned = _cards.Count > 0 && _cards.All(c => c.Signed);
            btnFinish.Enabled = _loadedPdfPath != null && _slots.Count > 0 && allSigned;
        }

        #endregion

        #region Cleanup

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _signatureService?.Dispose();
                // pdfOverlay este al ShellForm — nu il dispose-uim noi
                if (_loadedPdfPath != null && File.Exists(_loadedPdfPath))
                    try { File.Delete(_loadedPdfPath); } catch { }

                // Detasam event handler ca sa nu ramana reference
                if (pdfOverlay != null)
                    pdfOverlay.RectangleDrawn -= OnRectangleDrawn;
            }
            base.Dispose(disposing);
        }

        #endregion
    }

    // ── Data model ────────────────────────────────────────────────────────────────

    /// <summary>
    /// A free-form signature slot — everything needed to place and capture a signature,
    /// stored as JSON attachment in the PDF.
    /// </summary>
    public class FreeFormSlot
    {
        [JsonProperty("SignatureId")] public int SignatureId { get; set; }
        [JsonProperty("SignerName")] public string SignerName { get; set; }
        [JsonProperty("Reason")] public string Reason { get; set; }
        [JsonProperty("Party")] public string Party { get; set; }
        [JsonProperty("OfficialRole")] public string OfficialRole { get; set; }
        [JsonProperty("Required")] public bool Required { get; set; }
        [JsonProperty("Biometric")] public bool Biometric { get; set; }
        [JsonProperty("Page")] public int Page { get; set; }
        [JsonProperty("X")] public float X { get; set; }
        [JsonProperty("Y")] public float Y { get; set; }
        [JsonProperty("W")] public float W { get; set; }
        [JsonProperty("H")] public float H { get; set; }
    }
}