﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WacomSignaturePdf.Controls;
using PdfiumViewer;

namespace WacomSignaturePdf.Forms
{
    public partial class EvaluareProbaForm
    {
        #region Layout Constants
        private const int SidebarW = 370;
        private const int ToolbarH = 36;
        private const int FieldX = 14;
        private const int ContentW = 342;  // SidebarW - FieldX*2

        private static readonly Color BgSidebar = Color.FromArgb(22, 42, 72);
        private static readonly Color BgTitle = Color.FromArgb(14, 28, 52);
        private static readonly Color BgContent = Color.FromArgb(245, 247, 250);
        private static readonly Color AccentBlue = Color.FromArgb(60, 130, 210);
        private static readonly Color AccentBorder = Color.FromArgb(90, 155, 225);
        private static readonly Color SectionFg = Color.FromArgb(110, 175, 230);
        private static readonly Color SubFg = Color.FromArgb(150, 185, 220);
        private static readonly Color CardsBg = Color.FromArgb(30, 52, 88);
        private static readonly Color StatusBg = Color.FromArgb(12, 24, 44);
        #endregion

        #region Controls
        private Button btnSelectFolder;
        private Label lblSelectedFolder;
        private ComboBox cmbDocument;
        private ToggleSwitch toggleSigned;
        private Label lblToggleLeft;
        private Label lblToggleRight;
        private Panel cardsPanel;
        private Button btnMirror;
        private Button btnZoomIn;
        private Button btnZoomOut;
        private PdfViewer pdfViewer;
        private Panel panelSidebar;
        private Panel panelContent;
        private Panel panelToolbar;
        private Panel panelStatus;
        internal DeviceStatusLabel deviceStatusLabel;
        internal OneDriveStatusLabel oneDriveStatusLabel;
        private Label lblCardCount;
        private Label lblFolderSection;
        private Label lblDocSection;
        private Label lblCardsSection;
        #endregion

        private void BuildLayout()
        {
            this.Text = "Evaluare Proba Practica";
            this.ClientSize = new Size(1100, 700);
            this.MinimumSize = new Size(900, 580);
            this.BackColor = BgContent;
            this.DoubleBuffered = true;
            this.Font = new Font("Segoe UI", 9f);

            BuildSidebar();
            BuildContentArea();

            this.Controls.Add(panelContent);
            this.Controls.Add(panelSidebar);
        }

        // ── SIDEBAR ───────────────────────────────────────────────────────────────
        private void BuildSidebar()
        {
            panelSidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = SidebarW,
                BackColor = BgSidebar,
            };

            // Title
            var panelTitle = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = BgTitle,
            };
            panelTitle.Controls.Add(new Label
            {
                Text = "EVALUARE PROBĂ PRACTICĂ",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(160, 200, 240),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent,
            });
            panelTitle.Controls.Add(new Panel { Dock = DockStyle.Bottom, Height = 2, BackColor = AccentBlue });

            // ── Folder ──
            lblFolderSection = MakeSectionLabel("DOSAR CANDIDAT", new Point(FieldX, 62));

            btnSelectFolder = new Button
            {
                Text = "Selectează dosar candidat...",
                Location = new Point(FieldX, 80),
                Size = new Size(ContentW, 32),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(40, 72, 118),
                ForeColor = Color.FromArgb(180, 210, 240),
                Font = new Font("Segoe UI", 9f),
                TextAlign = ContentAlignment.MiddleLeft,
                Cursor = Cursors.Hand,
                Padding = new Padding(8, 0, 0, 0),
            };
            btnSelectFolder.FlatAppearance.BorderSize = 1;
            btnSelectFolder.FlatAppearance.BorderColor = Color.FromArgb(60, 105, 170);
            btnSelectFolder.Click += (s, e) => OpenFolderPicker();

            lblSelectedFolder = new Label
            {
                Text = "",
                Location = new Point(FieldX, 116),
                Size = new Size(ContentW, 16),
                Font = new Font("Segoe UI", 8f, FontStyle.Italic),
                ForeColor = Color.FromArgb(100, 165, 225),
                BackColor = Color.Transparent,
                AutoEllipsis = true,
            };

            // ── Document ──
            lblDocSection = MakeSectionLabel("DOCUMENT", new Point(FieldX, 144));

            cmbDocument = new ComboBox
            {
                Location = new Point(FieldX, 162),
                Size = new Size(ContentW, 26),
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(30, 56, 92),
                ForeColor = Color.White,
            };
            cmbDocument.SelectedIndexChanged += (s, e) => OnDocumentSelected();

            // ── Toggle filtru ──
            var panelToggle = new Panel
            {
                Location = new Point(FieldX, 200),
                Size = new Size(ContentW, 28),
                BackColor = Color.Transparent,
            };

            lblToggleLeft = new Label
            {
                Text = "Nesemnate / Partial",
                Location = new Point(0, 0),
                Size = new Size(130, 28),
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = AccentBlue,
                TextAlign = ContentAlignment.MiddleLeft,
            };

            toggleSigned = new ToggleSwitch
            {
                Location = new Point(134, 4),
                Size = new Size(46, 20),
                IsOn = false,
            };
            toggleSigned.Toggled += (s, e) => OnToggleChanged();

            lblToggleRight = new Label
            {
                Text = "Semnate + Sigilate",
                Location = new Point(184, 0),
                Size = new Size(130, 28),
                Font = new Font("Segoe UI", 8f),
                ForeColor = SubFg,
                TextAlign = ContentAlignment.MiddleLeft,
            };

            panelToggle.Controls.Add(lblToggleLeft);
            panelToggle.Controls.Add(toggleSigned);
            panelToggle.Controls.Add(lblToggleRight);

            // ── Cards ──
            lblCardsSection = MakeSectionLabel("SEMNATURI", new Point(FieldX, 240));

            lblCardCount = new Label
            {
                Location = new Point(FieldX, 258),
                Size = new Size(ContentW, 16),
                Font = new Font("Segoe UI", 8f),
                ForeColor = SubFg,
                BackColor = Color.Transparent,
                Text = "",
            };

            cardsPanel = new Panel
            {
                Location = new Point(FieldX, 278),
                Size = new Size(ContentW, 360),
                BackColor = CardsBg,
                AutoScroll = true,
                BorderStyle = BorderStyle.None,
            };

            // ── Status bar ──
            panelStatus = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 28,
                BackColor = StatusBg,
            };

            deviceStatusLabel = new DeviceStatusLabel
            {
                Location = new Point(10, 4),
                Size = new Size(160, 20),
            };
            oneDriveStatusLabel = new OneDriveStatusLabel
            {
                Location = new Point(180, 4),
                Size = new Size(160, 20),
            };
            panelStatus.Controls.Add(deviceStatusLabel);
            panelStatus.Controls.Add(oneDriveStatusLabel);

            panelSidebar.Controls.Add(panelTitle);
            panelSidebar.Controls.Add(lblFolderSection);
            panelSidebar.Controls.Add(btnSelectFolder);
            panelSidebar.Controls.Add(lblSelectedFolder);
            panelSidebar.Controls.Add(lblDocSection);
            panelSidebar.Controls.Add(cmbDocument);
            panelSidebar.Controls.Add(panelToggle);
            panelSidebar.Controls.Add(lblCardsSection);
            panelSidebar.Controls.Add(lblCardCount);
            panelSidebar.Controls.Add(cardsPanel);
            panelSidebar.Controls.Add(panelStatus);

            panelSidebar.Resize += (s, e) => RecalcSidebarLayout();
        }

        private void RecalcSidebarLayout()
        {
            int statusH = panelStatus?.Height ?? 28;
            int bottom = panelSidebar.ClientSize.Height - statusH - 4;
            cardsPanel.Height = bottom - cardsPanel.Top;
            cardsPanel.Width = panelSidebar.ClientSize.Width - FieldX * 2;
        }

        // ── CONTENT ───────────────────────────────────────────────────────────────
        private void BuildContentArea()
        {
            panelContent = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = BgContent,
            };

            panelToolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = ToolbarH,
                BackColor = Color.White,
                Padding = new Padding(6, 4, 6, 4),
            };
            panelToolbar.Controls.Add(new Panel { Dock = DockStyle.Bottom, Height = 1, BackColor = Color.FromArgb(210, 218, 230) });

            btnZoomIn = MakeToolbarButton("🔍+", "Zoom in");
            btnZoomIn.Click += (s, e) => { if (pdfViewer?.Renderer != null) pdfViewer.Renderer.Zoom *= 1.2; };

            btnZoomOut = MakeToolbarButton("🔍−", "Zoom out");
            btnZoomOut.Click += (s, e) => { if (pdfViewer?.Renderer != null) pdfViewer.Renderer.Zoom /= 1.2; };

            btnMirror = new Button
            {
                Text = "⊞  Oglindire",
                Dock = DockStyle.Right,
                Width = 120,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(40, 70, 130),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor = Cursors.Hand,
            };
            btnMirror.FlatAppearance.BorderSize = 1;
            btnMirror.FlatAppearance.BorderColor = Color.FromArgb(90, 120, 180);
            btnMirror.Click += btnMirror_Click;

            panelToolbar.Controls.Add(btnMirror);
            panelToolbar.Controls.Add(btnZoomOut);
            panelToolbar.Controls.Add(btnZoomIn);

            pdfViewer = new PdfViewer
            {
                Dock = DockStyle.Fill,
                ShowToolbar = false,
                ShowBookmarks = false,
                BackColor = Color.FromArgb(240, 242, 245),
            };

            panelContent.Controls.Add(pdfViewer);
            panelContent.Controls.Add(panelToolbar);
        }

        #region Helpers
        private Label MakeSectionLabel(string text, Point location) => new Label
        {
            Text = text,
            Location = location,
            Size = new Size(ContentW, 14),
            Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
            ForeColor = SectionFg,
            BackColor = Color.Transparent,
        };

        private Button MakeToolbarButton(string text, string tooltip)
        {
            var btn = new Button
            {
                Text = text,
                Dock = DockStyle.Left,
                Width = 36,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = Color.FromArgb(60, 80, 120),
                Font = new Font("Segoe UI", 9f),
                Cursor = Cursors.Hand,
            };
            btn.FlatAppearance.BorderSize = 0;
            new ToolTip().SetToolTip(btn, tooltip);
            return btn;
        }
        #endregion
    }
}